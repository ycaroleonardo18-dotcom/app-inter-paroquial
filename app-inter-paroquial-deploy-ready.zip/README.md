# App Inter Paroquial

Sistema de Gerenciamento Paroquial - Aplicação Full-Stack com React, TypeScript, tRPC e MySQL.

## 🎯 Funcionalidades

- **Autenticação**: Sistema de login com paróquia, usuário e senha
- **Dashboard**: Interface intuitiva para usuários e administradores
- **Gerenciamento de Escalas**: Controle de escalas de trabalho
- **Eventos**: Registro e visualização de eventos paroquiais
- **Avisos**: Sistema de notificações e avisos
- **Administração**: Painel completo para gerenciar usuários, configurações e conteúdo

## 🏗️ Arquitetura

### Frontend
- **React 18** com TypeScript
- **Vite** como bundler
- **TailwindCSS** para estilos
- **tRPC** para comunicação com backend
- **Wouter** para roteamento
- **React Hook Form** para formulários
- **React Query** para gerenciamento de estado

### Backend
- **Express.js** para servidor HTTP
- **tRPC** para API type-safe
- **Drizzle ORM** para banco de dados
- **MySQL** como banco de dados

## 📁 Estrutura do Projeto

```
app-inter-paroquial/
├── client/
│   └── src/
│       ├── pages/           # Páginas da aplicação
│       ├── components/      # Componentes reutilizáveis
│       ├── hooks/          # Custom hooks
│       ├── contexts/       # Context API
│       ├── lib/            # Utilitários
│       ├── _core/          # Configurações core
│       ├── App.tsx         # Componente raiz
│       ├── main.tsx        # Ponto de entrada
│       └── index.css       # Estilos globais
├── server/
│   ├── _core/             # Configuração tRPC
│   ├── routers.ts         # Rotas da API
│   └── index.ts           # Servidor Express
├── drizzle/
│   ├── schema.ts          # Esquema do banco de dados
│   └── migrations/        # Migrações
├── package.json
├── tsconfig.json
├── vite.config.ts
├── drizzle.config.ts
└── README.md
```

## 🚀 Instalação e Execução

### Pré-requisitos
- Node.js 18+
- pnpm (ou npm/yarn)
- MySQL 8+

### Instalação

```bash
# Instalar dependências
pnpm install

# Configurar variáveis de ambiente
cp .env.example .env

# Executar migrações do banco de dados
pnpm db:push
```

### Desenvolvimento

```bash
# Iniciar servidor de desenvolvimento (frontend + backend)
pnpm dev

# Frontend estará disponível em http://localhost:5173
# Backend estará disponível em http://localhost:3000
```

### Build

```bash
# Build para produção
pnpm build

# Executar build
pnpm start
```

## 📝 Variáveis de Ambiente

Crie um arquivo `.env` na raiz do projeto:

```env
# Database
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=
DB_NAME=app_paroquial

# Server
PORT=3000
CLIENT_URL=http://localhost:5173

# Client
VITE_API_URL=http://localhost:3000
```

## 🔐 Autenticação

O sistema utiliza autenticação baseada em sessão com tokens armazenados no localStorage. 

**Credenciais de teste:**
- Paróquia: Paróquia São José
- Usuário: usuario_teste
- Senha: senha123

## 📚 Documentação

Para mais informações sobre as tecnologias utilizadas:
- [React](https://react.dev)
- [TypeScript](https://www.typescriptlang.org)
- [tRPC](https://trpc.io)
- [Drizzle ORM](https://orm.drizzle.team)
- [TailwindCSS](https://tailwindcss.com)

## 📄 Licença

MIT

## 👥 Contribuindo

Contribuições são bem-vindas! Por favor, abra uma issue ou pull request.
