import { AppLayout } from "@/components/AppLayout";
import { useSessionAuth } from "@/hooks/useSessionAuth";
import { useLocation } from "wouter";
import { ROUTES } from "@/const";
import { useEffect } from "react";
import { Calendar, Bell } from "lucide-react";

export function Home() {
  const { loading, isAuthenticated } = useSessionAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!loading && !isAuthenticated) {
      setLocation(ROUTES.LOGIN);
    }
  }, [loading, isAuthenticated, setLocation]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  const features = [
    {
      icon: Calendar,
      title: "Escalas",
      description: "Gerencie as escalas de trabalho da paróquia",
      href: ROUTES.ESCALAS,
    },
    {
      icon: Calendar,
      title: "Eventos",
      description: "Visualize e gerencie os eventos programados",
      href: ROUTES.EVENTOS,
    },
    {
      icon: Bell,
      title: "Avisos",
      description: "Fique atualizado com os avisos importantes",
      href: ROUTES.AVISOS,
    },
  ];

  return (
    <AppLayout>
      <div className="space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-4xl font-bold text-gray-900 mb-2">
            Bem-vindo ao App Paroquial
          </h1>
          <p className="text-lg text-gray-600">
            Sistema de Gerenciamento para Paróquias
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature) => (
            <button
              key={feature.href}
              onClick={() => window.location.href = feature.href}
              className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow text-left group"
            >
              <div className="flex items-start gap-4">
                <div className="p-3 bg-blue-100 rounded-lg group-hover:bg-blue-200 transition-colors">
                  <feature.icon className="w-6 h-6 text-blue-600" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900 mb-1">
                    {feature.title}
                  </h3>
                  <p className="text-sm text-gray-600">
                    {feature.description}
                  </p>
                </div>
              </div>
            </button>
          ))}
        </div>

        {/* Quick Stats */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">
            Resumo do Sistema
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 bg-blue-50 rounded-lg">
              <p className="text-sm text-gray-600 mb-1">Usuários Ativos</p>
              <p className="text-2xl font-bold text-blue-600">--</p>
            </div>
            <div className="p-4 bg-green-50 rounded-lg">
              <p className="text-sm text-gray-600 mb-1">Eventos Próximos</p>
              <p className="text-2xl font-bold text-green-600">--</p>
            </div>
            <div className="p-4 bg-purple-50 rounded-lg">
              <p className="text-sm text-gray-600 mb-1">Avisos Pendentes</p>
              <p className="text-2xl font-bold text-purple-600">--</p>
            </div>
          </div>
        </div>

        {/* Info Box */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <p className="text-sm text-blue-800">
            💡 <strong>Dica:</strong> Use o menu lateral para navegar entre as
            diferentes seções do sistema.
          </p>
        </div>
      </div>
    </AppLayout>
  );
}
