import { AppLayout } from "@/components/AppLayout";
import { useSessionAuth } from "@/hooks/useSessionAuth";
import { useLocation } from "wouter";
import { ROUTES } from "@/const";
import { useEffect } from "react";

export function Perfil() {
  const { session, loading, isAuthenticated } = useSessionAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!loading && !isAuthenticated) {
      setLocation(ROUTES.LOGIN);
    }
  }, [loading, isAuthenticated, setLocation]);

  if (loading || !isAuthenticated) {
    return <div>Carregando...</div>;
  }

  return (
    <AppLayout>
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Meu Perfil</h1>
        <div className="bg-card border border-border rounded-lg p-6">
          <div className="space-y-4">
            <div>
              <label className="text-sm text-muted-foreground">Usuário</label>
              <p className="font-semibold">{session?.username}</p>
            </div>
            <div>
              <label className="text-sm text-muted-foreground">Função</label>
              <p className="font-semibold capitalize">{session?.role}</p>
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
