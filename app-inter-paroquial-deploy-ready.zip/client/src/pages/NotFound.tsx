import { useLocation } from "wouter";
import { ROUTES } from "@/const";

export function NotFound() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="text-center">
        <h1 className="text-6xl font-bold mb-4">404</h1>
        <p className="text-xl text-muted-foreground mb-8">Página não encontrada</p>
        <button
          onClick={() => setLocation(ROUTES.HOME)}
          className="px-6 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90"
        >
          Voltar para Home
        </button>
      </div>
    </div>
  );
}
