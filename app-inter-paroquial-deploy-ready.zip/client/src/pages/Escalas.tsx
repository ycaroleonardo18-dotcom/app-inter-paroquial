import { AppLayout } from "@/components/AppLayout";
import { useSessionAuth } from "@/hooks/useSessionAuth";
import { useLocation } from "wouter";
import { ROUTES } from "@/const";
import { useEffect } from "react";

export function Escalas() {
  const { loading, isAuthenticated } = useSessionAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!loading && !isAuthenticated) {
      setLocation(ROUTES.LOGIN);
    }
  }, [loading, isAuthenticated, setLocation]);

  if (loading || !isAuthenticated) {
    return <div>Carregando...</div>;
  }

  return (
    <AppLayout>
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Escalas</h1>
        <div className="bg-card border border-border rounded-lg p-6">
          <p className="text-muted-foreground">Nenhuma escala disponível no momento.</p>
        </div>
      </div>
    </AppLayout>
  );
}
