import { AppLayout } from "@/components/AppLayout";
import { useSessionAuth } from "@/hooks/useSessionAuth";
import { useLocation } from "wouter";
import { ROUTES } from "@/const";
import { useEffect } from "react";

export function AdminDashboard() {
  const { loading, isAuthenticated, isAdmin } = useSessionAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!loading && (!isAuthenticated || !isAdmin)) {
      setLocation(ROUTES.LOGIN);
    }
  }, [loading, isAuthenticated, isAdmin, setLocation]);

  if (loading || !isAuthenticated || !isAdmin) {
    return <div>Carregando...</div>;
  }

  return (
    <AppLayout>
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Dashboard Administrativo</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="bg-card border border-border rounded-lg p-6">
            <h3 className="font-semibold mb-2">Usuários</h3>
            <p className="text-2xl font-bold">0</p>
          </div>
          <div className="bg-card border border-border rounded-lg p-6">
            <h3 className="font-semibold mb-2">Escalas</h3>
            <p className="text-2xl font-bold">0</p>
          </div>
          <div className="bg-card border border-border rounded-lg p-6">
            <h3 className="font-semibold mb-2">Eventos</h3>
            <p className="text-2xl font-bold">0</p>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
