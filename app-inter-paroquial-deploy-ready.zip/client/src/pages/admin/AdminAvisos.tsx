import { AppLayout } from "@/components/AppLayout";
import { useSessionAuth } from "@/hooks/useSessionAuth";
import { useLocation } from "wouter";
import { ROUTES } from "@/const";
import { useEffect } from "react";

export function AdminAvisos() {
  const { loading, isAuthenticated, isAdmin } = useSessionAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!loading && (!isAuthenticated || !isAdmin)) {
      setLocation(ROUTES.LOGIN);
    }
  }, [loading, isAuthenticated, isAdmin, setLocation]);

  if (loading || !isAuthenticated || !isAdmin) {
    return <div>Carregando...</div>;
  }

  return (
    <AppLayout>
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Gerenciar Avisos</h1>
        <div className="bg-card border border-border rounded-lg p-6">
          <p className="text-muted-foreground">Nenhum aviso disponível no momento.</p>
        </div>
      </div>
    </AppLayout>
  );
}
