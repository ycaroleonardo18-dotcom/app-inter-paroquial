import { useEffect, useState, useCallback } from "react";
import { useLocation } from "wouter";
import { ROUTES } from "@/const";

export interface Session {
  userId: number;
  username: string;
  role: "admin" | "user";
  parishId: number;
  token: string;
}

interface UseSessionAuthReturn {
  session: Session | null;
  loading: boolean;
  isAuthenticated: boolean;
  isAdmin: boolean;
  login: (sessionData: Session) => void;
  logout: () => void;
}

export function useSessionAuth(): UseSessionAuthReturn {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [, setLocation] = useLocation();

  // Inicializar sessão do localStorage
  useEffect(() => {
    try {
      const token = localStorage.getItem("session_token");
      const sessionData = localStorage.getItem("session_data");

      if (token && sessionData) {
        const parsedSession = JSON.parse(sessionData) as Session;
        
        // Validar estrutura da sessão
        if (
          parsedSession.userId &&
          parsedSession.username &&
          parsedSession.role &&
          parsedSession.parishId &&
          parsedSession.token === token
        ) {
          setSession(parsedSession);
        } else {
          // Sessão inválida, limpar
          localStorage.removeItem("session_token");
          localStorage.removeItem("session_data");
        }
      }
    } catch (error) {
      console.error("Error loading session:", error);
      localStorage.removeItem("session_token");
      localStorage.removeItem("session_data");
    } finally {
      setLoading(false);
    }
  }, []);

  const login = useCallback((sessionData: Session) => {
    try {
      // Validar dados de sessão
      if (
        !sessionData.userId ||
        !sessionData.username ||
        !sessionData.role ||
        !sessionData.parishId ||
        !sessionData.token
      ) {
        throw new Error("Invalid session data");
      }

      localStorage.setItem("session_token", sessionData.token);
      localStorage.setItem("session_data", JSON.stringify(sessionData));
      setSession(sessionData);
    } catch (error) {
      console.error("Error saving session:", error);
      throw error;
    }
  }, []);

  const logout = useCallback(() => {
    try {
      localStorage.removeItem("session_token");
      localStorage.removeItem("session_data");
      setSession(null);
      setLocation(ROUTES.LOGIN);
    } catch (error) {
      console.error("Error during logout:", error);
    }
  }, [setLocation]);

  return {
    session,
    loading,
    isAuthenticated: !!session,
    isAdmin: session?.role === "admin",
    login,
    logout,
  };
}
