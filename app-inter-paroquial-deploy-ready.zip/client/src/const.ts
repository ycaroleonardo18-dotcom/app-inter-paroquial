export const API_URL = import.meta.env.VITE_API_URL || "http://localhost:3000";

export const ROUTES = {
  HOME: "/",
  LOGIN: "/login",
  ESCALAS: "/escalas",
  EVENTOS: "/eventos",
  AVISOS: "/avisos",
  PERFIL: "/perfil",
  ADMIN_DASHBOARD: "/admin/dashboard",
  ADMIN_ESCALAS: "/admin/escalas",
  ADMIN_EVENTOS: "/admin/eventos",
  ADMIN_AVISOS: "/admin/avisos",
  ADMIN_USUARIOS: "/admin/usuarios",
  ADMIN_CONFIGURACOES: "/admin/configuracoes",
};

export const ROLES = {
  ADMIN: "admin",
  USER: "user",
} as const;

export const PARISHES = [
  { id: 1, name: "Paróquia São José" },
  { id: 2, name: "Paróquia Principal" },
] as const;
