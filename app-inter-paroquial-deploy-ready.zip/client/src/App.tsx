import { Route, Switch } from "wouter";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { ThemeProvider } from "@/contexts/ThemeContext";
import { Home } from "@/pages/Home";
import { Escalas } from "@/pages/Escalas";
import { Eventos } from "@/pages/Eventos";
import { Avisos } from "@/pages/Avisos";
import { Perfil } from "@/pages/Perfil";
import { AdminDashboard } from "@/pages/admin/AdminDashboard";
import { AdminEscalas } from "@/pages/admin/AdminEscalas";
import { AdminEventos } from "@/pages/admin/AdminEventos";
import { AdminAvisos } from "@/pages/admin/AdminAvisos";
import { AdminUsuarios } from "@/pages/admin/AdminUsuarios";
import { AdminConfiguracoes } from "@/pages/admin/AdminConfiguracoes";
import { Login } from "@/pages/Login";
import { NotFound } from "@/pages/NotFound";

function Router() {
  return (
    <Switch>
      {/* Auth Pages */}
      <Route path="/login" component={Login} />

      {/* User Pages */}
      <Route path="/" component={Home} />
      <Route path="/escalas" component={Escalas} />
      <Route path="/eventos" component={Eventos} />
      <Route path="/avisos" component={Avisos} />
      <Route path="/perfil" component={Perfil} />

      {/* Admin Pages */}
      <Route path="/admin/dashboard" component={AdminDashboard} />
      <Route path="/admin/escalas" component={AdminEscalas} />
      <Route path="/admin/eventos" component={AdminEventos} />
      <Route path="/admin/avisos" component={AdminAvisos} />
      <Route path="/admin/usuarios" component={AdminUsuarios} />
      <Route path="/admin/configuracoes" component={AdminConfiguracoes} />

      {/* 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <ErrorBoundary>
        <Router />
      </ErrorBoundary>
    </ThemeProvider>
  );
}
