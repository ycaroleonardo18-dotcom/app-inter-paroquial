import React, { useState, useCallback } from "react";
import { useSessionAuth } from "@/hooks/useSessionAuth";
import { useLocation } from "wouter";
import {
  Menu,
  LogOut,
  Home,
  Calendar,
  Bell,
  Users,
  Settings,
  X,
} from "lucide-react";
import { ROUTES } from "@/const";

interface AppLayoutProps {
  children: React.ReactNode;
}

interface MenuItem {
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  href: string;
}

export function AppLayout({ children }: AppLayoutProps) {
  const { session, logout, isAdmin } = useSessionAuth();
  const [, setLocation] = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleNavigation = useCallback(
    (href: string) => {
      setLocation(href);
      setSidebarOpen(false);
    },
    [setLocation]
  );

  const handleLogout = useCallback(() => {
    if (confirm("Tem certeza que deseja sair?")) {
      logout();
    }
  }, [logout]);

  if (!session) {
    return null;
  }

  const menuItems: MenuItem[] = [
    { label: "Home", icon: Home, href: ROUTES.HOME },
    { label: "Escalas", icon: Calendar, href: ROUTES.ESCALAS },
    { label: "Eventos", icon: Calendar, href: ROUTES.EVENTOS },
    { label: "Avisos", icon: Bell, href: ROUTES.AVISOS },
    ...(isAdmin
      ? [
          {
            label: "Admin Dashboard",
            icon: Users,
            href: ROUTES.ADMIN_DASHBOARD,
          },
          { label: "Admin Usuários", icon: Users, href: ROUTES.ADMIN_USUARIOS },
          {
            label: "Admin Configurações",
            icon: Settings,
            href: ROUTES.ADMIN_CONFIGURACOES,
          },
        ]
      : []),
  ];

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Overlay para mobile */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-20 md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        } md:translate-x-0 fixed md:relative w-64 h-full bg-white border-r border-gray-200 transition-transform duration-300 z-30 flex flex-col`}
      >
        {/* Header do Sidebar */}
        <div className="p-4 border-b border-gray-200 flex items-center justify-between">
          <h2 className="text-lg font-bold text-gray-900">Menu</h2>
          <button
            onClick={() => setSidebarOpen(false)}
            className="md:hidden p-1 hover:bg-gray-100 rounded"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navegação */}
        <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
          {menuItems.map((item) => (
            <button
              key={item.href}
              onClick={() => handleNavigation(item.href)}
              className="w-full flex items-center gap-3 px-4 py-2 rounded-lg hover:bg-gray-100 text-left text-gray-700 hover:text-gray-900 transition-colors"
            >
              <item.icon className="w-5 h-5 flex-shrink-0" />
              <span>{item.label}</span>
            </button>
          ))}
        </nav>

        {/* Footer do Sidebar */}
        <div className="p-4 border-t border-gray-200 space-y-2">
          <div className="px-4 py-2 text-sm">
            <p className="text-gray-600">Usuário</p>
            <p className="font-semibold text-gray-900 truncate">
              {session.username}
            </p>
          </div>
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-4 py-2 rounded-lg hover:bg-red-50 text-red-600 hover:text-red-700 transition-colors font-medium"
          >
            <LogOut className="w-5 h-5" />
            <span>Sair</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between shadow-sm">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="md:hidden p-2 hover:bg-gray-100 rounded-lg"
            aria-label="Toggle sidebar"
          >
            <Menu className="w-5 h-5" />
          </button>

          <div className="flex-1" />

          <div className="flex items-center gap-4">
            <span className="text-sm text-gray-600 hidden sm:inline">
              {session.username}
            </span>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 overflow-auto p-4 md:p-6">
          <div className="max-w-7xl mx-auto">{children}</div>
        </main>
      </div>
    </div>
  );
}
