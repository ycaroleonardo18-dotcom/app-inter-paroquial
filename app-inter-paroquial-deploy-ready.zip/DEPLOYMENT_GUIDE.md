# Guia de Implantação - App Inter Paroquial

Este guia detalha o processo de implantação do seu aplicativo full-stack, utilizando **Vercel** para o Frontend (React/Vite) e **Render** para o Backend (Node.js/Express/tRPC).

## 🚀 Pré-requisitos

1.  **Conta Git:** O projeto deve estar em um repositório Git (GitHub, GitLab, Bitbucket).
2.  **Contas de Hospedagem:** Contas ativas no [Vercel](https://vercel.com/) e [Render](https://render.com/).
3.  **Banco de Dados:** Um serviço de banco de dados MySQL (pode ser no Render, AWS RDS, ou outro provedor).

## 1. Implantação do Backend (Render)

O Render será usado para hospedar o servidor Node.js e o tRPC.

### 1.1. Configuração do Banco de Dados

1.  Crie um serviço de banco de dados MySQL no Render ou use um provedor externo.
2.  Obtenha a URL de conexão (ou Host, User, Password, Name).

### 1.2. Configuração do Serviço Web

1.  No Render, crie um novo **Web Service**.
2.  Conecte ao seu repositório Git.
3.  **Nome:** `app-paroquial-backend`
4.  **Ambiente:** `Node`
5.  **Branch:** `main` (ou a sua branch principal)
6.  **Build Command:** `pnpm install && pnpm server:build`
7.  **Start Command:** `node server/dist/index.js`
8.  **Variáveis de Ambiente:** Use o arquivo `render.yaml` como referência e adicione as seguintes variáveis (substituindo os valores):
    -   `NODE_ENV`: `production`
    -   `DB_HOST`: Host do seu banco de dados
    -   `DB_USER`: Usuário do seu banco de dados
    -   `DB_PASSWORD`: Senha do seu banco de dados
    -   `DB_NAME`: Nome do seu banco de dados
    -   `CLIENT_URL`: **Deixe em branco por enquanto.** Você o preencherá após a implantação do Frontend.

9.  Implante o serviço. Anote a URL pública do seu backend (ex: `https://app-paroquial-backend.onrender.com`).

## 2. Implantação do Frontend (Vercel)

O Vercel será usado para hospedar o aplicativo React estático.

### 2.1. Configuração do Projeto

1.  No Vercel, crie um novo projeto.
2.  Conecte ao seu repositório Git.
3.  **Root Directory:** Deixe em branco (o `vercel.json` na raiz cuidará da configuração).
4.  **Build Command:** `pnpm install && pnpm client:build`
5.  **Output Directory:** `client/dist`
6.  **Variáveis de Ambiente:** Adicione a variável de ambiente do tRPC:
    -   `VITE_API_URL`: **URL pública do seu backend no Render** (ex: `https://app-paroquial-backend.onrender.com`)

7.  Implante o projeto. Anote a URL pública do seu frontend (ex: `https://app-paroquial-frontend.vercel.app`).

## 3. Finalização e Conexão

1.  **Atualize o Backend (Render):**
    -   Volte para as variáveis de ambiente do seu serviço de backend no Render.
    -   Atualize a variável `CLIENT_URL` com a URL pública do seu frontend no Vercel (ex: `https://app-paroquial-frontend.vercel.app`).
    -   Isso garante que o CORS do backend permita requisições do seu frontend.
    -   **Reinicie o serviço de backend no Render.**

2.  **Migração do Banco de Dados:**
    -   Se você estiver usando o Drizzle, você precisará executar a migração do esquema.
    -   Você pode fazer isso manualmente a partir do seu ambiente local ou configurar um pipeline de build no Render para rodar o comando `pnpm db:push` (Recomendado: faça isso manualmente ou em um serviço de "Job" no Render para evitar que rode a cada deploy).

## 4. Teste Final

-   Acesse a URL do seu frontend no Vercel.
-   O aplicativo deve carregar e se comunicar com o backend no Render.

---

**Observação:** O arquivo `vercel.json` e `render.yaml` foram adicionados à raiz do projeto para facilitar a configuração inicial. Certifique-se de que eles estão no seu repositório Git.
