import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  int,
  timestamp,
  boolean,
} from "drizzle-orm/mysql-core";

export const parishes = mysqlTable("parishes", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow(),
});

export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 255 }).notNull().unique(),
  password: varchar("password", { length: 255 }).notNull(),
  role: mysqlEnum("role", ["admin", "user"]).default("user"),
  parishId: int("parishId").references(() => parishes.id),
  createdAt: timestamp("createdAt").defaultNow(),
});

export const sessions = mysqlTable("sessions", {
  id: serial("id").primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  token: varchar("token", { length: 255 }).notNull().unique(),
  expiresAt: timestamp("expiresAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow(),
});

export const schedules = mysqlTable("schedules", {
  id: serial("id").primaryKey(),
  parishId: int("parishId").notNull().references(() => parishes.id),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  startDate: timestamp("startDate").notNull(),
  endDate: timestamp("endDate").notNull(),
  createdAt: timestamp("createdAt").defaultNow(),
});

export const events = mysqlTable("events", {
  id: serial("id").primaryKey(),
  parishId: int("parishId").notNull().references(() => parishes.id),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  date: timestamp("date").notNull(),
  location: varchar("location", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow(),
});

export const notices = mysqlTable("notices", {
  id: serial("id").primaryKey(),
  parishId: int("parishId").notNull().references(() => parishes.id),
  title: varchar("title", { length: 255 }).notNull(),
  content: text("content").notNull(),
  published: boolean("published").default(false),
  createdAt: timestamp("createdAt").defaultNow(),
});
