import { router, publicProcedure } from "./_core/trpc";
import { z } from "zod";
import { TRPCError } from "@trpc/server";

// Schemas de validação
const userIdSchema = z.object({ id: z.number().int().positive() });

export const appRouter = router({
  health: publicProcedure.query(() => {
    return { 
      status: "ok",
      timestamp: new Date().toISOString(),
      version: "1.0.0"
    };
  }),

  user: router({
    list: publicProcedure.query(async () => {
      try {
        // TODO: Implementar busca de usuários do banco de dados
        return [];
      } catch (error) {
        console.error("Error fetching users:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to fetch users",
        });
      }
    }),

    get: publicProcedure
      .input(userIdSchema)
      .query(async ({ input }) => {
        try {
          // TODO: Implementar busca de usuário específico
          if (!input.id) {
            throw new TRPCError({
              code: "BAD_REQUEST",
              message: "User ID is required",
            });
          }
          return null;
        } catch (error) {
          if (error instanceof TRPCError) throw error;
          console.error("Error fetching user:", error);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to fetch user",
          });
        }
      }),
  }),

  schedule: router({
    list: publicProcedure.query(async () => {
      try {
        // TODO: Implementar busca de escalas
        return [];
      } catch (error) {
        console.error("Error fetching schedules:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to fetch schedules",
        });
      }
    }),

    recent: publicProcedure.query(async () => {
      try {
        // TODO: Implementar busca de escalas recentes
        return [];
      } catch (error) {
        console.error("Error fetching recent schedules:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to fetch recent schedules",
        });
      }
    }),
  }),

  event: router({
    list: publicProcedure.query(async () => {
      try {
        // TODO: Implementar busca de eventos
        return [];
      } catch (error) {
        console.error("Error fetching events:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to fetch events",
        });
      }
    }),
  }),

  notice: router({
    list: publicProcedure.query(async () => {
      try {
        // TODO: Implementar busca de avisos
        return [];
      } catch (error) {
        console.error("Error fetching notices:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to fetch notices",
        });
      }
    }),
  }),
});

export type AppRouter = typeof appRouter;
