# 🚀 Guia de Setup - App Inter Paroquial

## Pré-requisitos

- **Node.js** 18+ ([Download](https://nodejs.org/))
- **pnpm** 8+ ([Instalação](https://pnpm.io/installation))
- **MySQL** 8+ ([Download](https://www.mysql.com/downloads/))

## 1️⃣ Clonar e Instalar

```bash
# Navegar para o diretório do projeto
cd app-inter-paroquial

# Instalar dependências
pnpm install
```

## 2️⃣ Configurar Banco de Dados

### Criar arquivo `.env`

```bash
cp .env.example .env
```

### Editar `.env` com suas credenciais

```env
# Database
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=sua_senha
DB_NAME=app_paroquial

# Server
PORT=3000
CLIENT_URL=http://localhost:5173

# Client
VITE_API_URL=http://localhost:3000
```

### Executar Migrações

```bash
# Criar tabelas no banco de dados
pnpm db:push
```

## 3️⃣ Iniciar Desenvolvimento

```bash
# Iniciar servidor de desenvolvimento
pnpm dev
```

Isso iniciará:
- **Frontend**: http://localhost:5173
- **Backend**: http://localhost:3000

## 4️⃣ Login

Use as credenciais padrão:

| Campo | Valor |
|-------|-------|
| **Paróquia** | Paróquia São José |
| **Usuário** | usuario_teste |
| **Senha** | senha123 |

## 📝 Scripts Disponíveis

```bash
# Desenvolvimento
pnpm dev              # Iniciar dev server (frontend + backend)
pnpm client:dev       # Apenas frontend
pnpm server:dev       # Apenas backend

# Build
pnpm build            # Build para produção
pnpm client:build     # Build frontend
pnpm server:build     # Build backend

# Banco de Dados
pnpm db:push          # Executar migrações
pnpm db:studio        # Abrir Drizzle Studio

# Qualidade
pnpm check            # Type checking
pnpm test             # Executar testes

# Outros
pnpm preview          # Visualizar build
```

## 🗄️ Gerenciar Banco de Dados

### Drizzle Studio (Interface Visual)

```bash
pnpm db:studio
```

Acesse: http://localhost:3000/studio

### MySQL CLI

```bash
mysql -u root -p app_paroquial
```

## 🐛 Troubleshooting

### Porta já em uso

```bash
# Mudar porta no .env
PORT=3001
VITE_API_URL=http://localhost:3001
```

### Erro de conexão com banco de dados

1. Verificar se MySQL está rodando
2. Verificar credenciais em `.env`
3. Criar banco de dados manualmente:

```sql
CREATE DATABASE app_paroquial;
```

### Limpar cache

```bash
# Remover node_modules e reinstalar
rm -rf node_modules pnpm-lock.yaml
pnpm install
```

## 📚 Documentação Adicional

- [React](https://react.dev)
- [TypeScript](https://www.typescriptlang.org)
- [tRPC](https://trpc.io)
- [Drizzle ORM](https://orm.drizzle.team)
- [Vite](https://vitejs.dev)
- [TailwindCSS](https://tailwindcss.com)

## 💡 Dicas

1. Use o Drizzle Studio para visualizar dados
2. Verifique o console do navegador para erros
3. Use as ferramentas de dev do navegador (F12)
4. Leia os logs do servidor para debugging

## 🆘 Suporte

Se encontrar problemas:

1. Verifique o arquivo `.env`
2. Verifique se MySQL está rodando
3. Limpe o cache (`rm -rf node_modules`)
4. Reinstale dependências (`pnpm install`)

---

**Pronto para começar! 🎉**
