# Resumo do Projeto - App Inter Paroquial

## 📋 Visão Geral

**App Inter Paroquial** é um sistema completo de gerenciamento paroquial desenvolvido com as mais modernas tecnologias web. A aplicação oferece uma interface intuitiva para gerenciar escalas, eventos, avisos e usuários de paróquias.

## 🎯 Objetivos Principais

1. **Centralizar** informações de gerenciamento paroquial
2. **Facilitar** a comunicação entre administradores e usuários
3. **Automatizar** processos de escalas e eventos
4. **Melhorar** a experiência do usuário com interface moderna

## 🛠️ Stack Tecnológico

### Frontend
- **React 18** - Framework UI
- **TypeScript** - Type safety
- **Vite** - Build tool rápido
- **TailwindCSS** - Styling
- **tRPC** - API type-safe
- **React Query** - State management
- **Wouter** - Roteamento leve
- **Lucide React** - Ícones
- **React Hook Form** - Formulários
- **Zod** - Validação de dados

### Backend
- **Express.js** - Framework HTTP
- **tRPC** - API type-safe
- **Drizzle ORM** - Database ORM
- **MySQL** - Banco de dados
- **Node.js** - Runtime

## 📁 Estrutura de Arquivos

```
app-inter-paroquial/
├── client/
│   ├── src/
│   │   ├── pages/
│   │   │   ├── admin/
│   │   │   │   ├── AdminDashboard.tsx
│   │   │   │   ├── AdminUsuarios.tsx
│   │   │   │   ├── AdminEscalas.tsx
│   │   │   │   ├── AdminEventos.tsx
│   │   │   │   ├── AdminAvisos.tsx
│   │   │   │   └── AdminConfiguracoes.tsx
│   │   │   ├── Login.tsx
│   │   │   ├── Home.tsx
│   │   │   ├── Escalas.tsx
│   │   │   ├── Eventos.tsx
│   │   │   ├── Avisos.tsx
│   │   │   ├── Perfil.tsx
│   │   │   └── NotFound.tsx
│   │   ├── components/
│   │   │   ├── AppLayout.tsx
│   │   │   └── ErrorBoundary.tsx
│   │   ├── hooks/
│   │   │   └── useSessionAuth.ts
│   │   ├── contexts/
│   │   │   └── ThemeContext.tsx
│   │   ├── lib/
│   │   │   └── trpc.ts
│   │   ├── App.tsx
│   │   ├── main.tsx
│   │   ├── const.ts
│   │   └── index.css
│   └── index.html
├── server/
│   ├── _core/
│   │   ├── context.ts
│   │   └── trpc.ts
│   ├── routers.ts
│   └── index.ts
├── drizzle/
│   ├── schema.ts
│   └── migrations/
├── package.json
├── tsconfig.json
├── vite.config.ts
├── drizzle.config.ts
├── .env.example
├── .gitignore
├── README.md
└── PROJECT_SUMMARY.md
```

## 🔑 Funcionalidades Principais

### Autenticação
- Login com paróquia, usuário e senha
- Sessões baseadas em tokens
- Armazenamento seguro no localStorage

### Dashboard
- Visão geral do sistema
- Estatísticas de usuários, escalas e eventos
- Acesso rápido a funcionalidades

### Gerenciamento de Escalas
- Criar, editar e deletar escalas
- Visualizar escalas por período
- Atribuir usuários às escalas

### Eventos
- Registrar eventos paroquiais
- Visualizar calendário de eventos
- Gerenciar detalhes de eventos

### Avisos
- Publicar avisos importantes
- Visualizar histórico de avisos
- Gerenciar avisos por paróquia

### Administração
- Gerenciar usuários
- Controlar permissões
- Configurações do sistema
- Gerenciar paróquias

## 🚀 Como Usar

### Instalação
```bash
# Instalar dependências
pnpm install

# Configurar banco de dados
pnpm db:push

# Iniciar desenvolvimento
pnpm dev
```

### Variáveis de Ambiente
Crie um arquivo `.env` baseado em `.env.example` com suas configurações de banco de dados.

### Credenciais Padrão
- **Paróquia**: Paróquia São José
- **Usuário**: usuario_teste
- **Senha**: senha123

## 🔒 Segurança

- Autenticação baseada em sessão
- Tokens com expiração
- Validação de dados com Zod
- Type-safety com TypeScript
- CORS configurado

## 📊 Banco de Dados

### Tabelas Principais
- `parishes` - Paróquias
- `users` - Usuários
- `sessions` - Sessões ativas
- `schedules` - Escalas
- `events` - Eventos
- `notices` - Avisos

## 🎨 Interface

- Design moderno com TailwindCSS
- Tema claro/escuro
- Responsivo (mobile, tablet, desktop)
- Ícones com Lucide React
- Componentes reutilizáveis

## 🧪 Testes

```bash
# Executar testes
pnpm test

# Testes com watch
pnpm test:watch
```

## 📦 Build

```bash
# Build para produção
pnpm build

# Visualizar build
pnpm preview
```

## 🤝 Contribuindo

1. Fork o projeto
2. Crie uma branch para sua feature (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add some AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

## 📝 Licença

Este projeto está sob a licença MIT.

## 📞 Suporte

Para suporte, abra uma issue no repositório.

---

**Desenvolvido com ❤️ usando React, TypeScript e tRPC**
